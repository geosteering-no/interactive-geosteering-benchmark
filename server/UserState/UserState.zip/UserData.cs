﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserState
{
    /// <summary>
    /// Contains all data which is sent to the user
    /// Should be enough to restore the game
    /// </summary>
    public class UserData
    {
    }
}
